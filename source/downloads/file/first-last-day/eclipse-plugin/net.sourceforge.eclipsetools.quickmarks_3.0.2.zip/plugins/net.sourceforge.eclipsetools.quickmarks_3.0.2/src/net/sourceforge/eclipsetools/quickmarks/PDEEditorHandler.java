// $Header: /cvsroot/eclipse-tools/net.sourceforge.eclipsetools.quickmarks/src/net/sourceforge/eclipsetools/quickmarks/PDEEditorHandler.java,v 1.2.2.1 2004/08/05 03:32:17 deerwood Exp $

/**********************************************************************
Copyright (c) 2004 Jesper Kamstrup Linnet and Georg Rehfeld.
All rights reserved. See http://eclipse-tools.sourceforge.net/quickmarks/.
This program and the accompanying materials are made available under the
terms of the Common Public License v1.0 which accompanies this distribution,
and is available at http://www.eclipse.org/legal/cpl-v10.html

Contributors:
    Jesper Kamstrup Linnet - Initial implementation
    Georg Rehfeld - port to Eclipse 3.0
**********************************************************************/

package net.sourceforge.eclipsetools.quickmarks;

import java.lang.reflect.Method;

import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.IDocumentProvider;

/**
 * Class implementing the functionality to get an ITextSelection and an
 * IDocumentProvider for PDE editors. The code uses reflection in order to avoid
 * adding dependencies to the PDE plugins.
 * <p>
 * This class isn't used in 3.0 any more. It is left in place, as it may be a
 * good sample for implementing other kinds of editor handlers, e.g. for the
 * WSAD editors. It will be marked as deprecated soon.
 * 
 * @author Jesper Kamstrup Linnet, eclipse@kamstrup-linnet.dk
 * @author Georg Rehfeld, georg.rehfeld@gmx.de
 */
class PDEEditorHandler implements IEditorHandler {
	// Type hierarchy of 3.0 PDE editors:
	// org.eclipse.pde.internal.ui.editor.plugin.ManifestEditor
	// OR org.eclipse.pde.internal.ui.editor.feature.FeatureEditor
	// org.eclipse.pde.internal.ui.editor.MultiSourceEditor
	// org.eclipse.pde.internal.ui.editor.PDEFormEditor
	// org.eclipse.ui.forms.editor.FormEditor
	// org.eclipse.ui.part.MultiPageEditorPart
	// org.eclipse.ui.part.EditorPart
	// org.eclipse.ui.part.WorkbenchPart
//-2.1-	private static final String EDITOR_CLASS =
//-2.1-		"org.eclipse.pde.internal.ui.editor.PDEMultiPageEditor"; //$NON-NLS-1$
	private static final String EDITOR_CLASS =
		"org.eclipse.pde.internal.ui.editor.PDEFormEditor"; //$NON-NLS-1$
	private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
	private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];

	/**
	 * Default constructor.
	 */
	public PDEEditorHandler() {
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.eclipsetools.quickmarks.IEditorHandler#getDocumentProvider()
	 */
	public IDocumentProvider getDocumentProvider(IEditorPart editor) {
//-2.1-		return (IDocumentProvider) invokeGetMethod(editor, "getDocumentProvider"); //$NON-NLS-1$
		IEditorInput input = editor.getEditorInput();
		// see org.eclipse.pde.internal.ui.editor.context.InputContextManager
		Object contextManager = invokeGetMethod(editor, "getContextManager"); //$NON-NLS-1$
		// see org.eclipse.pde.internal.ui.editor.context.InputContext
		Object context = invokeGetMethod(contextManager, "getContext", IEditorInput.class, input); //$NON-NLS-1$
		IDocumentProvider result = (IDocumentProvider) invokeGetMethod(context, "getDocumentProvider"); //$NON-NLS-1$
		return result;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.eclipsetools.quickmarks.IEditorHandler#getTextSelection()
	 */
	public ITextSelection getTextSelection(IEditorPart editor) {
		ISelection selection = (ISelection) invokeGetMethod(editor, "getSelection"); //$NON-NLS-1$
		if (selection instanceof ITextSelection) {
			return (ITextSelection) selection;
		}
		return null;
	}

	/**
	 * Gets and invokes the method with the given name on the given object.
	 * The invoked method is called without any parameters.
	 * Any exceptions thrown while trying to invoke the method are logged
	 * and null is returned then.
	 * 
	 * @param obj  the object to invoke the method on
	 * @param methodName  the name of the method to invoke
	 * @return  whatever the invoked method returns or <code>null</code>
	 */
	private Object invokeGetMethod(Object obj, String methodName) {
		Object result = null;
		try {
			Method method = obj.getClass().getMethod(methodName, EMPTY_CLASS_ARRAY);
			result = method.invoke(obj, EMPTY_OBJECT_ARRAY);
		} catch (Exception e) {
			QuickmarksPlugin.log(e);
		}
		return result;
	}

	/**
	 * Gets and invokes the method with the given name on the given object.
	 * The invoked method is called with the one given parameter.
	 * Any exceptions thrown while trying to invoke the method are logged
	 * and null is returned then.
	 * 
	 * @param obj  the object to invoke the method on
	 * @param methodName  the name of the method to invoke
	 * @param clazz0  the type of the given parameter
	 * @param param0  the one and only parameter to the method invoked
	 * @return  whatever the invoked method returns or <code>null</code>
	 */
	private Object invokeGetMethod(Object obj, String methodName, Class clazz0, Object param0) {
		Object result = null;
		try {
			Method method = obj.getClass().getMethod(methodName, new Class[] { clazz0 });
			result = method.invoke(obj, new Object[] { param0 });
		} catch (Exception e) {
			QuickmarksPlugin.log(e);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.eclipsetools.quickmarks.AbstractEditorHandler#isHandler(java.lang.Class)
	 */
	public boolean isHandler(Class clazz) {
		while (!Object.class.equals(clazz)) {
			if (EDITOR_CLASS.equals(clazz.getName())) {
				return true;
			}
			clazz = clazz.getSuperclass();
		}
		return false;
	}
}

// EOF
